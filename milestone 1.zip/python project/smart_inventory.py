import sqlite3

# Connect to database
conn = sqlite3.connect("smart_inventory.db")
cursor = conn.cursor()

# Create table
cursor.execute("""
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    category TEXT,
    price REAL,
    supplier TEXT,
    stock INTEGER,
    reorder_level INTEGER
)
""")
conn.commit()


class InventorySystem:

    def add_product(self):
        name = input("Product Name: ")
        category = input("Category: ")
        price = float(input("Price: "))
        supplier = input("Supplier: ")
        stock = int(input("Stock Quantity: "))
        reorder = int(input("Reorder Level: "))

        cursor.execute("""
        INSERT INTO products (name, category, price, supplier, stock, reorder_level)
        VALUES (?, ?, ?, ?, ?, ?)
        """, (name, category, price, supplier, stock, reorder))

        conn.commit()
        print("✅ Product Added Successfully!\n")

    def view_products(self):
        cursor.execute("SELECT * FROM products")
        rows = cursor.fetchall()

        if not rows:
            print("No products available.\n")
            return

        print("\n------ PRODUCT LIST ------")
        for row in rows:
            print(f"\nID: {row[0]}")
            print(f"Name: {row[1]}")
            print(f"Category: {row[2]}")
            print(f"Price: ₹{row[3]}")
            print(f"Supplier: {row[4]}")
            print(f"Stock: {row[5]}")
            print(f"Reorder Level: {row[6]}")

            if row[5] <= row[6]:
                print("⚠ Low Stock! Reorder Needed")

    def update_stock(self):
        pid = int(input("Enter Product ID: "))
        new_stock = int(input("Enter New Stock Quantity: "))

        cursor.execute("UPDATE products SET stock=? WHERE id=?", (new_stock, pid))
        conn.commit()
        print("✅ Stock Updated Successfully!\n")

    def delete_product(self):
        pid = int(input("Enter Product ID to Delete: "))
        cursor.execute("DELETE FROM products WHERE id=?", (pid,))
        conn.commit()
        print("✅ Product Deleted Successfully!\n")


system = InventorySystem()

while True:
    print("\n===== SMART INVENTORY MENU =====")
    print("1. Add Product")
    print("2. View Products")
    print("3. Update Stock")
    print("4. Delete Product")
    print("5. Exit")

    choice = input("Enter choice: ")

    if choice == "1":
        system.add_product()
    elif choice == "2":
        system.view_products()
    elif choice == "3":
        system.update_stock()
    elif choice == "4":
        system.delete_product()
    elif choice == "5":
        print("Exiting System...")
        break
    else:
        print("Invalid choice!")

conn.close()