import { formatDate } from './utils';

export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  stock: number;
  threshold: number;
  supplier: string;
  lastUpdated: Date;
}

export interface Order {
  id: string;
  customer: string;
  items: number;
  total: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  date: Date;
}

export interface Supplier {
  id: string;
  name: string;
  email: string;
  phone: string;
  products: number;
  rating: number;
  status: 'active' | 'inactive';
}

export interface Alert {
  id: string;
  type: 'info' | 'warning' | 'danger' | 'success';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
}

export const products: Product[] = [
  {
    id: '1',
    name: 'Wireless Headphones',
    category: 'Electronics',
    price: 99.99,
    stock: 45,
    threshold: 20,
    supplier: 'TechCorp',
    lastUpdated: new Date('2024-01-15'),
  },
  {
    id: '2',
    name: 'Smart Watch',
    category: 'Electronics',
    price: 199.99,
    stock: 12,
    threshold: 15,
    supplier: 'GadgetPro',
    lastUpdated: new Date('2024-01-14'),
  },
  {
    id: '3',
    name: 'Running Shoes',
    category: 'Footwear',
    price: 79.99,
    stock: 8,
    threshold: 10,
    supplier: 'SportMax',
    lastUpdated: new Date('2024-01-13'),
  },
  {
    id: '4',
    name: 'Coffee Maker',
    category: 'Appliances',
    price: 149.99,
    stock: 23,
    threshold: 10,
    supplier: 'HomeGoods',
    lastUpdated: new Date('2024-01-12'),
  },
  {
    id: '5',
    name: 'Yoga Mat',
    category: 'Fitness',
    price: 29.99,
    stock: 67,
    threshold: 25,
    supplier: 'FitLife',
    lastUpdated: new Date('2024-01-11'),
  },
  {
    id: '6',
    name: 'Backpack',
    category: 'Accessories',
    price: 49.99,
    stock: 5,
    threshold: 10,
    supplier: 'TravelGear',
    lastUpdated: new Date('2024-01-10'),
  },
];

export const orders: Order[] = [
  {
    id: 'ORD-001',
    customer: 'John Smith',
    items: 3,
    total: 249.97,
    status: 'delivered',
    date: new Date('2024-01-15'),
  },
  {
    id: 'ORD-002',
    customer: 'Emma Watson',
    items: 2,
    total: 179.98,
    status: 'shipped',
    date: new Date('2024-01-14'),
  },
  {
    id: 'ORD-003',
    customer: 'Michael Brown',
    items: 5,
    total: 459.95,
    status: 'processing',
    date: new Date('2024-01-13'),
  },
  {
    id: 'ORD-004',
    customer: 'Sarah Johnson',
    items: 1,
    total: 79.99,
    status: 'pending',
    date: new Date('2024-01-12'),
  },
  {
    id: 'ORD-005',
    customer: 'David Lee',
    items: 4,
    total: 359.96,
    status: 'cancelled',
    date: new Date('2024-01-11'),
  },
];

export const suppliers: Supplier[] = [
  {
    id: 'SUP-001',
    name: 'TechCorp',
    email: 'sales@techcorp.com',
    phone: '+1 (555) 123-4567',
    products: 45,
    rating: 4.8,
    status: 'active',
  },
  {
    id: 'SUP-002',
    name: 'GadgetPro',
    email: 'orders@gadgetpro.com',
    phone: '+1 (555) 234-5678',
    products: 32,
    rating: 4.5,
    status: 'active',
  },
  {
    id: 'SUP-003',
    name: 'SportMax',
    email: 'info@sportmax.com',
    phone: '+1 (555) 345-6789',
    products: 28,
    rating: 4.2,
    status: 'active',
  },
  {
    id: 'SUP-004',
    name: 'HomeGoods',
    email: 'contact@homegoods.com',
    phone: '+1 (555) 456-7890',
    products: 56,
    rating: 4.9,
    status: 'inactive',
  },
];

export const alerts: Alert[] = [
  {
    id: '1',
    type: 'warning',
    title: 'Low Stock Alert',
    message: 'Backpack is running low on stock (5 units remaining)',
    timestamp: new Date('2024-01-15T10:30:00'),
    read: false,
  },
  {
    id: '2',
    type: 'danger',
    title: 'Critical Stock',
    message: 'Smart Watch has fallen below threshold (12 units)',
    timestamp: new Date('2024-01-15T09:15:00'),
    read: false,
  },
  {
    id: '3',
    type: 'success',
    title: 'Order Delivered',
    message: 'Order ORD-001 has been successfully delivered',
    timestamp: new Date('2024-01-15T08:45:00'),
    read: true,
  },
  {
    id: '4',
    type: 'info',
    title: 'New Supplier',
    message: 'FashionHub has been added as a new supplier',
    timestamp: new Date('2024-01-14T16:20:00'),
    read: true,
  },
];

export const salesData = [
  { name: 'Jan', sales: 4000, profit: 2400 },
  { name: 'Feb', sales: 3000, profit: 1398 },
  { name: 'Mar', sales: 2000, profit: 9800 },
  { name: 'Apr', sales: 2780, profit: 3908 },
  { name: 'May', sales: 1890, profit: 4800 },
  { name: 'Jun', sales: 2390, profit: 3800 },
  { name: 'Jul', sales: 3490, profit: 4300 },
];

export const categoryData = [
  { name: 'Electronics', value: 35 },
  { name: 'Footwear', value: 25 },
  { name: 'Appliances', value: 20 },
  { name: 'Fitness', value: 15 },
  { name: 'Accessories', value: 5 },
];