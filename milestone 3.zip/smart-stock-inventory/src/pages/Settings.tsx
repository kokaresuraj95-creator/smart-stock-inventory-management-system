import React, { useState } from 'react';
import { Save, User, Bell, Shield, Store, Palette, Globe, CreditCard } from 'lucide-react';
import Button from '../components/Button';
import Input from '../components/Input';

const Settings: React.FC = () => {
  const [activeTab, setActiveTab] = useState('general');

  const tabs = [
    { id: 'general', label: 'General', icon: Store },
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'appearance', label: 'Appearance', icon: Palette },
    { id: 'billing', label: 'Billing', icon: CreditCard },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <h1 className="text-3xl font-bold text-gradient">Settings</h1>

      <div className="flex gap-6">
        {/* Sidebar */}
        <div className="w-64 space-y-2">
          {tabs.map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                  activeTab === tab.id
                    ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600'
                    : 'hover:bg-gray-100 dark:hover:bg-gray-800'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content */}
        <div className="flex-1 bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg">
          {activeTab === 'general' && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold">General Settings</h2>
              
              <div className="space-y-4">
                <Input label="Store Name" placeholder="My Store" />
                <Input label="Store Email" type="email" placeholder="store@example.com" />
                <Input label="Phone" placeholder="+1 234 567 890" />
                <Input label="Address" placeholder="123 Business St" />
                
                <div className="grid grid-cols-2 gap-4">
                  <Input label="City" placeholder="New York" />
                  <Input label="Country" placeholder="USA" />
                </div>
                
                <div className="pt-4">
                  <Button icon={<Save />}>Save Changes</Button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'profile' && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold">Profile Settings</h2>
              
              <div className="flex items-center gap-6 mb-6">
                <div className="w-20 h-20 bg-gradient-to-r from-primary-600 to-primary-400 rounded-2xl flex items-center justify-center text-white text-2xl font-bold">
                  A
                </div>
                <Button variant="outline">Change Avatar</Button>
              </div>

              <div className="space-y-4">
                <Input label="Full Name" placeholder="Admin User" />
                <Input label="Email" type="email" placeholder="admin@store.com" />
                <Input label="Role" value="Administrator" disabled />
                
                <div className="pt-4">
                  <Button icon={<Save />}>Update Profile</Button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'notifications' && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold">Notification Preferences</h2>
              
              <div className="space-y-4">
                <label className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
                  <div>
                    <p className="font-medium">Email Notifications</p>
                    <p className="text-sm text-gray-500">Receive updates via email</p>
                  </div>
                  <input type="checkbox" className="toggle" defaultChecked />
                </label>
                
                <label className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
                  <div>
                    <p className="font-medium">Push Notifications</p>
                    <p className="text-sm text-gray-500">Browser notifications</p>
                  </div>
                  <input type="checkbox" className="toggle" defaultChecked />
                </label>
                
                <label className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
                  <div>
                    <p className="font-medium">SMS Alerts</p>
                    <p className="text-sm text-gray-500">Critical alerts via SMS</p>
                  </div>
                  <input type="checkbox" className="toggle" />
                </label>
                
                <div className="pt-4">
                  <Button icon={<Save />}>Save Preferences</Button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'security' && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold">Security Settings</h2>
              
              <div className="space-y-4">
                <Input label="Current Password" type="password" />
                <Input label="New Password" type="password" />
                <Input label="Confirm Password" type="password" />
                
                <label className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
                  <div>
                    <p className="font-medium">Two-Factor Authentication</p>
                    <p className="text-sm text-gray-500">Add extra security</p>
                  </div>
                  <input type="checkbox" className="toggle" />
                </label>
                
                <div className="pt-4">
                  <Button icon={<Save />}>Update Security</Button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'appearance' && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold">Appearance Settings</h2>
              
              <div className="space-y-4">
                <label className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
                  <div>
                    <p className="font-medium">Dark Mode</p>
                    <p className="text-sm text-gray-500">Toggle dark theme</p>
                  </div>
                  <input type="checkbox" className="toggle" />
                </label>
                
                <div>
                  <p className="text-sm font-medium mb-2">Primary Color</p>
                  <div className="flex gap-3">
                    {['blue', 'purple', 'green', 'red', 'orange'].map(color => (
                      <button
                        key={color}
                        className={`w-8 h-8 rounded-full bg-${color}-500 hover:scale-110 transition-transform`}
                      />
                    ))}
                  </div>
                </div>
                
                <div>
                  <p className="text-sm font-medium mb-2">Font Size</p>
                  <select className="input-field">
                    <option>Small</option>
                    <option selected>Medium</option>
                    <option>Large</option>
                  </select>
                </div>
                
                <div className="pt-4">
                  <Button icon={<Save />}>Save Appearance</Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Settings;
// Toggle switch ke liye yeh component use karo:
const ToggleSwitch = ({ checked, onChange, label, description }: any) => (
  <label className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl cursor-pointer">
    <div>
      <p className="font-medium">{label}</p>
      {description && <p className="text-sm text-gray-500">{description}</p>}
    </div>
    <div className="relative">
      <input
        type="checkbox"
        className="sr-only"
        checked={checked}
        onChange={onChange}
      />
      <div className={`toggle-bg ${checked ? 'bg-primary-600' : 'bg-gray-300 dark:bg-gray-600'}`} />
      <div className={`toggle-dot ${checked ? 'translate-x-5' : ''}`} />
    </div>
  </label>
);