import React, { useState } from 'react';
import { Bell, CheckCheck, Filter, Clock } from 'lucide-react';
import AlertItem from '../components/AlertItem';
import Button from '../components/Button';
import Badge from '../components/Badge';
import { alerts } from '../lib/data';

const Alerts: React.FC = () => {
  const [filter, setFilter] = useState<'all' | 'unread' | 'read'>('all');
  
  const filteredAlerts = alerts.filter(alert => {
    if (filter === 'unread') return !alert.read;
    if (filter === 'read') return alert.read;
    return true;
  });

  const unreadCount = alerts.filter(a => !a.read).length;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gradient">Alerts & Notifications</h1>
        <div className="flex gap-3">
          <Button variant="outline" icon={<CheckCheck />}>
            Mark All Read
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-lg">
          <p className="text-sm text-gray-500">Total Alerts</p>
          <p className="text-2xl font-bold">{alerts.length}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-lg">
          <p className="text-sm text-gray-500">Unread</p>
          <p className="text-2xl font-bold text-red-600">{unreadCount}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-lg">
          <p className="text-sm text-gray-500">Read</p>
          <p className="text-2xl font-bold text-green-600">{alerts.length - unreadCount}</p>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg overflow-hidden">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h2 className="text-lg font-semibold">Notifications</h2>
            <Badge variant={unreadCount > 0 ? 'danger' : 'success'} pulse={unreadCount > 0}>
              {unreadCount} unread
            </Badge>
          </div>
          <div className="flex gap-2">
            <Button 
              variant={filter === 'all' ? 'primary' : 'ghost'} 
              size="sm"
              onClick={() => setFilter('all')}
            >
              All
            </Button>
            <Button 
              variant={filter === 'unread' ? 'primary' : 'ghost'} 
              size="sm"
              onClick={() => setFilter('unread')}
            >
              Unread
            </Button>
            <Button 
              variant={filter === 'read' ? 'primary' : 'ghost'} 
              size="sm"
              onClick={() => setFilter('read')}
            >
              Read
            </Button>
          </div>
        </div>

        <div className="divide-y divide-gray-200 dark:divide-gray-700">
          {filteredAlerts.length > 0 ? (
            filteredAlerts.map(alert => (
              <AlertItem
                key={alert.id}
                type={alert.type}
                title={alert.title}
                message={alert.message}
                timestamp={alert.timestamp}
                read={alert.read}
                onDismiss={() => console.log('Dismiss:', alert.id)}
              />
            ))
          ) : (
            <div className="p-8 text-center text-gray-500">
              <Bell className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No alerts found</p>
            </div>
          )}
        </div>

        <div className="p-4 border-t border-gray-200 dark:border-gray-700 flex items-center justify-between">
          <p className="text-sm text-gray-500">
            Showing {filteredAlerts.length} of {alerts.length} alerts
          </p>
          <Button variant="ghost" size="sm">
            View All
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg">
          <h3 className="text-lg font-semibold mb-4">Alert Preferences</h3>
          <div className="space-y-3">
            <label className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
              <div>
                <p className="font-medium">Low Stock Alerts</p>
                <p className="text-sm text-gray-500">Get notified when products are low</p>
              </div>
              <input type="checkbox" className="toggle" defaultChecked />
            </label>
            <label className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
              <div>
                <p className="font-medium">Order Updates</p>
                <p className="text-sm text-gray-500">Order status changes</p>
              </div>
              <input type="checkbox" className="toggle" defaultChecked />
            </label>
            <label className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
              <div>
                <p className="font-medium">Supplier News</p>
                <p className="text-sm text-gray-500">Updates from suppliers</p>
              </div>
              <input type="checkbox" className="toggle" />
            </label>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg">
          <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
          <div className="space-y-4">
            {alerts.slice(0, 3).map(alert => (
              <div key={alert.id} className="flex items-start gap-3">
                <div className={`p-2 rounded-lg bg-${alert.type}-100 dark:bg-${alert.type}-900/20`}>
                  <Clock className={`w-4 h-4 text-${alert.type}-600`} />
                </div>
                <div>
                  <p className="text-sm font-medium">{alert.title}</p>
                  <p className="text-xs text-gray-500">
                    {alert.timestamp.toLocaleTimeString()} ago
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Alerts;