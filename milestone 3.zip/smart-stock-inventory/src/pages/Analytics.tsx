import React from 'react';
import { TrendingUp, TrendingDown, DollarSign, Package, ShoppingCart, Users } from 'lucide-react';
import Chart from '../components/Chart';
import StatsCard from '../components/StatsCard';
import { salesData, categoryData } from '../lib/data';
import { formatCurrency } from '../lib/utils';

const Analytics: React.FC = () => {
  // Calculate metrics
  const totalRevenue = salesData.reduce((sum, item) => sum + item.sales, 0);
  const totalProfit = salesData.reduce((sum, item) => sum + item.profit, 0);
  const avgSales = totalRevenue / salesData.length;
  const growthRate = ((salesData[salesData.length - 1].sales - salesData[0].sales) / salesData[0].sales) * 100;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gradient">Analytics Dashboard</h1>
        <select className="input-field w-48">
          <option>Last 7 days</option>
          <option>Last 30 days</option>
          <option>Last 3 months</option>
          <option>Last year</option>
        </select>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Total Revenue"
          value={formatCurrency(totalRevenue)}
          icon={<DollarSign className="w-6 h-6" />}
          trend={15.5}
          trendLabel="vs last month"
          color="primary"
        />
        <StatsCard
          title="Total Profit"
          value={formatCurrency(totalProfit)}
          icon={<TrendingUp className="w-6 h-6" />}
          trend={12.3}
          trendLabel="vs last month"
          color="success"
        />
        <StatsCard
          title="Average Sales"
          value={formatCurrency(avgSales)}
          icon={<ShoppingCart className="w-6 h-6" />}
          trend={8.2}
          trendLabel="vs last month"
          color="warning"
        />
        <StatsCard
          title="Growth Rate"
          value={`${growthRate.toFixed(1)}%`}
          icon={<TrendingUp className="w-6 h-6" />}
          trend={growthRate}
          trendLabel="overall"
          color={growthRate > 0 ? 'success' : 'danger'}
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Chart
          data={salesData}
          type="line"
          dataKeys={['sales', 'profit']}
          title="Revenue vs Profit Trend"
          colors={['#3b82f6', '#10b981']}
          height={350}
        />
        
        <Chart
          data={salesData}
          type="area"
          dataKeys={['sales']}
          title="Sales Overview"
          colors={['#8b5cf6']}
          height={350}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Chart
          data={salesData}
          type="bar"
          dataKeys={['sales', 'profit']}
          title="Monthly Comparison"
          colors={['#f59e0b', '#ef4444']}
          height={350}
        />
        
        <Chart
          data={categoryData}
          type="pie"
          dataKeys={['value']}
          title="Category Distribution"
          colors={['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6']}
          height={350}
        />
      </div>

      {/* Detailed Statistics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg">
          <h3 className="text-lg font-semibold mb-4">Top Products</h3>
          <div className="space-y-4">
            {[1, 2, 3, 4, 5].map(i => (
              <div key={i} className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Product {i}</p>
                  <p className="text-sm text-gray-500">Category {i}</p>
                </div>
                <p className="font-semibold">{formatCurrency(1500 * i)}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg">
          <h3 className="text-lg font-semibold mb-4">Sales by Day</h3>
          <div className="space-y-4">
            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, i) => (
              <div key={day} className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>{day}</span>
                  <span>{formatCurrency(1000 + i * 200)}</span>
                </div>
                <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-primary-600 rounded-full"
                    style={{ width: `${60 + i * 5}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg">
          <h3 className="text-lg font-semibold mb-4">Customer Insights</h3>
          <div className="space-y-4">
            <div className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
              <p className="text-sm text-gray-500">New Customers</p>
              <p className="text-2xl font-bold">+124</p>
              <p className="text-xs text-green-600">↑ 12% vs last month</p>
            </div>
            <div className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
              <p className="text-sm text-gray-500">Returning Customers</p>
              <p className="text-2xl font-bold">+89</p>
              <p className="text-xs text-green-600">↑ 8% vs last month</p>
            </div>
            <div className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
              <p className="text-sm text-gray-500">Avg Order Value</p>
              <p className="text-2xl font-bold">{formatCurrency(245)}</p>
              <p className="text-xs text-green-600">↑ 5% vs last month</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;