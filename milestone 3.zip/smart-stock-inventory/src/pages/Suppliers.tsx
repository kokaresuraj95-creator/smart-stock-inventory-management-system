import React, { useState } from 'react';
import { Plus, Search, Edit, Trash2, Mail, Phone, Star } from 'lucide-react';
import Table from '../components/Table';
import Button from '../components/Button';
import Input from '../components/Input';
import Badge from '../components/Badge';
import Modal from '../components/Modal';
import { suppliers, Supplier } from '../lib/data';

const Suppliers: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(null);

  const filteredSuppliers = suppliers.filter(supplier =>
    supplier.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    supplier.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    supplier.phone.includes(searchTerm)
  );

  const columns = [
    { key: 'name', header: 'Supplier Name' },
    { key: 'email', header: 'Email' },
    { key: 'phone', header: 'Phone' },
    { 
      key: 'products', 
      header: 'Products',
      render: (supplier: Supplier) => (
        <Badge variant="info">{supplier.products} items</Badge>
      )
    },
    { 
      key: 'rating', 
      header: 'Rating',
      render: (supplier: Supplier) => (
        <div className="flex items-center gap-1">
          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
          <span>{supplier.rating}</span>
        </div>
      )
    },
    { 
      key: 'status', 
      header: 'Status',
      render: (supplier: Supplier) => (
        <Badge variant={supplier.status === 'active' ? 'success' : 'danger'}>
          {supplier.status}
        </Badge>
      )
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (supplier: Supplier) => (
        <div className="flex gap-2">
          <button className="p-2 hover:bg-blue-100 dark:hover:bg-blue-900/20 text-blue-600 rounded-lg transition-colors">
            <Mail className="w-4 h-4" />
          </button>
          <button className="p-2 hover:bg-green-100 dark:hover:bg-green-900/20 text-green-600 rounded-lg transition-colors">
            <Phone className="w-4 h-4" />
          </button>
          <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
            <Edit className="w-4 h-4" />
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gradient">Suppliers</h1>
        <Button onClick={() => setIsModalOpen(true)} icon={<Plus />}>
          Add Supplier
        </Button>
      </div>

      <div className="flex gap-4 items-center">
        <div className="flex-1">
          <Input
            placeholder="Search suppliers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            icon={<Search className="w-4 h-4" />}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-lg">
          <p className="text-sm text-gray-500">Total Suppliers</p>
          <p className="text-2xl font-bold">{suppliers.length}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-lg">
          <p className="text-sm text-gray-500">Active</p>
          <p className="text-2xl font-bold text-green-600">
            {suppliers.filter(s => s.status === 'active').length}
          </p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-lg">
          <p className="text-sm text-gray-500">Total Products</p>
          <p className="text-2xl font-bold text-blue-600">
            {suppliers.reduce((sum, s) => sum + s.products, 0)}
          </p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-lg">
          <p className="text-sm text-gray-500">Avg Rating</p>
          <p className="text-2xl font-bold text-yellow-600">
            {(suppliers.reduce((sum, s) => sum + s.rating, 0) / suppliers.length).toFixed(1)}
          </p>
        </div>
      </div>

      <Table
        data={filteredSuppliers}
        columns={columns}
        onRowClick={(supplier) => {
          setSelectedSupplier(supplier);
          setIsModalOpen(true);
        }}
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedSupplier(null);
        }}
        title={selectedSupplier ? 'Edit Supplier' : 'Add New Supplier'}
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button>
              {selectedSupplier ? 'Update' : 'Add'} Supplier
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <Input label="Supplier Name" defaultValue={selectedSupplier?.name} />
          <Input label="Email" type="email" defaultValue={selectedSupplier?.email} />
          <Input label="Phone" defaultValue={selectedSupplier?.phone} />
          <Input label="Products Count" type="number" defaultValue={selectedSupplier?.products} />
          <Input label="Rating" type="number" step="0.1" defaultValue={selectedSupplier?.rating} />
        </div>
      </Modal>
    </div>
  );
};

export default Suppliers;