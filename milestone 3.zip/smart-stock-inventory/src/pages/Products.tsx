import React, { useState } from 'react';
import { Plus, Search, Edit, Trash2, Filter } from 'lucide-react';
import Table from '../components/Table';
import Button from '../components/Button';
import Input from '../components/Input';
import Badge from '../components/Badge';
import Modal from '../components/Modal';
import { products, Product } from '../lib/data';
import { formatCurrency, calculateStockStatus } from '../lib/utils';

const Products: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.supplier.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const columns = [
    { key: 'name', header: 'Product Name' },
    { key: 'category', header: 'Category' },
    {
      key: 'price',
      header: 'Price',
      render: (product: Product) => formatCurrency(product.price),
    },
    {
      key: 'stock',
      header: 'Stock',
      render: (product: Product) => (
        <div className="flex items-center gap-2">
          <span>{product.stock}</span>
          <Badge variant={calculateStockStatus(product.stock, product.threshold)}>
            {product.stock <= product.threshold ? 'Low' : 'In Stock'}
          </Badge>
        </div>
      ),
    },
    { key: 'supplier', header: 'Supplier' },
    {
      key: 'actions',
      header: 'Actions',
      render: (product: Product) => (
        <div className="flex gap-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setSelectedProduct(product);
              setIsModalOpen(true);
            }}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <Edit className="w-4 h-4" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              // Handle delete
            }}
            className="p-2 hover:bg-red-100 dark:hover:bg-red-900/20 text-red-600 rounded-lg transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gradient">Products</h1>
        <Button onClick={() => setIsModalOpen(true)} icon={<Plus />}>
          Add Product
        </Button>
      </div>

      <div className="flex gap-4 items-center">
        <div className="flex-1">
          <Input
            placeholder="Search products..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            icon={<Search className="w-4 h-4" />}
          />
        </div>
        <Button variant="outline" icon={<Filter />}>
          Filter
        </Button>
      </div>

      <Table
        data={filteredProducts}
        columns={columns}
        onRowClick={(product) => {
          setSelectedProduct(product);
          setIsModalOpen(true);
        }}
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedProduct(null);
        }}
        title={selectedProduct ? 'Edit Product' : 'Add New Product'}
        size="lg"
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button>
              {selectedProduct ? 'Update' : 'Create'} Product
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <Input label="Product Name" defaultValue={selectedProduct?.name} />
          <Input label="Category" defaultValue={selectedProduct?.category} />
          <Input label="Price" type="number" defaultValue={selectedProduct?.price} />
          <Input label="Stock" type="number" defaultValue={selectedProduct?.stock} />
          <Input label="Threshold" type="number" defaultValue={selectedProduct?.threshold} />
          <Input label="Supplier" defaultValue={selectedProduct?.supplier} />
        </div>
      </Modal>
    </div>
  );
};

export default Products;