import React from 'react';
import { Package, ShoppingCart, Users, AlertTriangle, TrendingUp, DollarSign } from 'lucide-react';
import StatsCard from '../components/StatsCard';
import Chart from '../components/Chart';
import Table from '../components/Table';
import Badge from '../components/Badge';
import { products, orders, salesData } from '../lib/data';
import { formatCurrency, formatNumber, calculateStockStatus } from '../lib/utils';

const Dashboard: React.FC = () => {
  const totalProducts = products.length;
  const totalOrders = orders.length;
  const lowStock = products.filter(p => p.stock <= p.threshold).length;
  const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);

  const recentOrders = orders.slice(0, 5);

  const columns = [
    { key: 'id', header: 'Order ID' },
    { key: 'customer', header: 'Customer' },
    {
      key: 'total',
      header: 'Total',
      render: (order: any) => formatCurrency(order.total),
    },
    {
      key: 'status',
      header: 'Status',
      render: (order: any) => {
        const variants: Record<string, 'success' | 'warning' | 'info' | 'danger'> = {
          delivered: 'success',
          shipped: 'info',
          processing: 'warning',
          pending: 'warning',
          cancelled: 'danger',
        };
        return <Badge variant={variants[order.status]}>{order.status}</Badge>;
      },
    },
    {
      key: 'date',
      header: 'Date',
      render: (order: any) => order.date.toLocaleDateString(),
    },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gradient">Dashboard</h1>
        <div className="flex gap-3">
          <button className="px-4 py-2 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-all duration-200 hover:scale-105 hover:shadow-lg">
            Generate Report
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Total Products"
          value={formatNumber(totalProducts)}
          icon={<Package className="w-6 h-6" />}
          trend={12}
          trendLabel="vs last month"
          color="primary"
        />
        <StatsCard
          title="Total Orders"
          value={formatNumber(totalOrders)}
          icon={<ShoppingCart className="w-6 h-6" />}
          trend={8}
          trendLabel="vs last month"
          color="success"
        />
        <StatsCard
          title="Low Stock Items"
          value={formatNumber(lowStock)}
          icon={<AlertTriangle className="w-6 h-6" />}
          trend={-5}
          trendLabel="vs last month"
          color="danger"
        />
        <StatsCard
          title="Total Revenue"
          value={formatCurrency(totalRevenue)}
          icon={<DollarSign className="w-6 h-6" />}
          trend={15}
          trendLabel="vs last month"
          color="warning"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Chart
          data={salesData}
          type="area"
          dataKeys={['sales', 'profit']}
          title="Sales Overview"
          height={300}
        />
        <Chart
          data={salesData}
          type="bar"
          dataKeys={['sales']}
          title="Monthly Sales"
          height={300}
        />
      </div>

      <div className="grid grid-cols-1 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg">
          <h2 className="text-xl font-semibold mb-4">Recent Orders</h2>
          <Table
            data={recentOrders}
            columns={columns}
            onRowClick={(order) => console.log('Clicked order:', order)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg">
          <h3 className="font-semibold mb-4">Stock Status</h3>
          <div className="space-y-4">
            {products.slice(0, 5).map((product) => {
              const status = calculateStockStatus(product.stock, product.threshold);
              return (
                <div key={product.id} className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">{product.name}</p>
                    <p className="text-xs text-gray-500">Stock: {product.stock}</p>
                  </div>
                  <Badge variant={status}>
                    {status === 'danger' ? 'Critical' : status === 'warning' ? 'Low' : 'Good'}
                  </Badge>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg">
          <h3 className="font-semibold mb-4">Top Categories</h3>
          <Chart
            data={[
              { name: 'Electronics', value: 35 },
              { name: 'Footwear', value: 25 },
              { name: 'Appliances', value: 20 },
              { name: 'Fitness', value: 15 },
              { name: 'Accessories', value: 5 },
            ]}
            type="pie"
            dataKeys={['value']}
            height={200}
          />
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg">
          <h3 className="font-semibold mb-4">Quick Actions</h3>
          <div className="space-y-3">
            <button className="w-full p-3 text-left bg-primary-50 dark:bg-primary-900/20 rounded-xl hover:scale-[1.02] transition-all duration-200">
              <p className="font-medium">Add New Product</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Create a new product listing</p>
            </button>
            <button className="w-full p-3 text-left bg-green-50 dark:bg-green-900/20 rounded-xl hover:scale-[1.02] transition-all duration-200">
              <p className="font-medium">Create Order</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Process a new customer order</p>
            </button>
            <button className="w-full p-3 text-left bg-yellow-50 dark:bg-yellow-900/20 rounded-xl hover:scale-[1.02] transition-all duration-200">
              <p className="font-medium">Restock Items</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Order from suppliers</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;