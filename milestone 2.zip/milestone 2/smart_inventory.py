import sqlite3

# database connect
conn = sqlite3.connect("stock.db")
cursor = conn.cursor()

# products table
cursor.execute("""
CREATE TABLE IF NOT EXISTS products(
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT,
price REAL,
quantity INTEGER
)
""")

# sales table
cursor.execute("""
CREATE TABLE IF NOT EXISTS sales(
sale_id INTEGER PRIMARY KEY AUTOINCREMENT,
product_name TEXT,
quantity INTEGER,
total_price REAL
)
""")

conn.commit()

# ---------------- ADD PRODUCT ----------------
def add_product():
    name = input("Enter product name: ")
    price = float(input("Enter price: "))
    qty = int(input("Enter quantity: "))

    cursor.execute(
        "INSERT INTO products(name,price,quantity) VALUES(?,?,?)",
        (name,price,qty)
    )
    conn.commit()

    print("Product Added Successfully")


# ---------------- VIEW PRODUCTS ----------------
def view_products():
    cursor.execute("SELECT * FROM products")
    data = cursor.fetchall()

    print("\nProduct List\n")
    for row in data:
        print(row)


# ---------------- UPDATE PRODUCT ----------------
def update_product():
    pid = int(input("Enter product ID to update: "))
    new_price = float(input("Enter new price: "))
    new_qty = int(input("Enter new quantity: "))

    cursor.execute(
        "UPDATE products SET price=?, quantity=? WHERE id=?",
        (new_price,new_qty,pid)
    )

    conn.commit()
    print("Product Updated")


# ---------------- DELETE PRODUCT ----------------
def delete_product():
    pid = int(input("Enter product ID to delete: "))

    cursor.execute("DELETE FROM products WHERE id=?", (pid,))
    conn.commit()

    print("Product Deleted")


# ---------------- RECORD SALE ----------------
def record_sale():
    name = input("Enter product name: ")
    qty = int(input("Enter quantity sold: "))

    cursor.execute("SELECT price,quantity FROM products WHERE name=?", (name,))
    product = cursor.fetchone()

    if product:
        price = product[0]
        stock_qty = product[1]

        if stock_qty >= qty:

            total = price * qty

            cursor.execute(
                "INSERT INTO sales(product_name,quantity,total_price) VALUES(?,?,?)",
                (name,qty,total)
            )

            new_qty = stock_qty - qty

            cursor.execute(
                "UPDATE products SET quantity=? WHERE name=?",
                (new_qty,name)
            )

            conn.commit()

            print("Sale Recorded. Total =", total)

        else:
            print("Not enough stock")

    else:
        print("Product not found")


# ---------------- VIEW SALES ----------------
def view_sales():

    cursor.execute("SELECT * FROM sales")
    data = cursor.fetchall()

    print("\nSales History\n")

    for row in data:
        print(row)


# ---------------- MENU ----------------
while True:

    print("\nSMART STOCK MANAGEMENT")
    print("1 Add Product")
    print("2 View Products")
    print("3 Update Product")
    print("4 Delete Product")
    print("5 Record Sale")
    print("6 View Sales")
    print("7 Exit")

    choice = input("Enter choice: ")

    if choice == "1":
        add_product()

    elif choice == "2":
        view_products()

    elif choice == "3":
        update_product()

    elif choice == "4":
        delete_product()

    elif choice == "5":
        record_sale()

    elif choice == "6":
        view_sales()

    elif choice == "7":
        print("Program Ended")
        break

    else:
        print("Invalid Choice")

conn.close()